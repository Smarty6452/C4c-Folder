import React from 'react'

const CollectionCard = () => {
  return (
    <div className='collectionCard'>
       

    </div>
  )
}

export default CollectionCard