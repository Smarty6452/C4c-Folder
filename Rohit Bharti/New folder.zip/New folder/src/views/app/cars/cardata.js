const cardata = [
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
    {
      id: 1,
      title: 'BMW',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      carbrand: "BMW",
      model: "BMWX5",
      seatingcapacity: "4",
      plateno: "0007",
      fueltype: "p-unleaded",
      fuelcapacity: "NA",
      year: "1916",
      color: "Black",
      hcharge: "NA",
      dcharge: "NA",
      wcharge: "NA",
      action: "NA",
      

    
    },
 
    
  ];
  
  export default cardata;
  