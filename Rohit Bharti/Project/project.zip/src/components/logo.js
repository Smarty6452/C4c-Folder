import React from 'react'
import logosrc from "../assets/img/logo_white.png";

const logo = () => {
  return (
    <div className='logo-container'>
        <img className='logo-login-signup' src={logosrc} alt="logo-signup-login"/>

    </div>
  )
}

export default logo