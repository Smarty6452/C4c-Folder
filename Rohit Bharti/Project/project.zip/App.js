import React from "react";
import 'antd/dist/antd.min.css';
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";


// import BrandSlider from "./Components/BrandSlider/BrandSlider";


export default function App() {
  return (
    <div className="hello">
   hello
    </div>
  );
}
