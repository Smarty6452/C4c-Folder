const data = [
  { title: 'dashboards.totalcar', icon: 'iconsminds-car', value: 70 },
  {
    title: 'dashboards.booking',
    icon: 'simple-icon-calendar',
    value: 120,
  },
  {
    title: 'dashboards.customer',
    icon: 'simple-icon-user',
    value: 25,
  },
  { title: 'dashboards.transcation', icon: 'simple-icon-check', value: 20 },
];
export default data;
