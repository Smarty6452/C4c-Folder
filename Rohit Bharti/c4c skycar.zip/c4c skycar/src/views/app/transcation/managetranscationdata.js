const cardata = [
    {
      id: 1,
      title: 'Rohit',
      img: '/assets/img/products/marble-cake-thumb.jpg',
      category: 'Car',
      createDate: '02.04.2018',
      status: 'ON HOLD',
      statusColor: 'primary',
      description: 'Wedding cake with flowers Macarons and blueberries',
      name: "Rohit",
      

    
    },
    
    
  ];
  
  export default cardata;
  